# filetags

by zs

简单的文件标签管理器,基于 Electron-vue 开发,

搜索功能基于 everything,

运行前需要开启[everything](www.voidtools.com)服务

## License

[GNU General Public License v3.0](LICENSE)


